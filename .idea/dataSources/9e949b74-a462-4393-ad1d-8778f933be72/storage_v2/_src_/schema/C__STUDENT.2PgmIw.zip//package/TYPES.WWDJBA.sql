create package types
as
type cursorType is ref cursor;
end types;
/

