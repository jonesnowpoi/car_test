create procedure gettestpaper(testpaper_cur out types.cursorType) is
begin
  open testpaper_cur for
  select * from (select * from question order by dbms_random.value) where rownum <= 10;
end gettestpaper;
/

