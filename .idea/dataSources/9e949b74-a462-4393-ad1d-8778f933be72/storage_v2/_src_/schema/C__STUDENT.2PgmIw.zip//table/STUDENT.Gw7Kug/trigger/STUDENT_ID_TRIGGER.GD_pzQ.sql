create trigger STUDENT_ID_TRIGGER
  before insert
  on STUDENT
  for each row
begin
  select STUDENT_SEQ.nextval into :new.ID from dual;
end STUDENT_ID_TRIGGER;
/

