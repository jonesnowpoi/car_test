create trigger PAPER_ID_TRIGGER
  before insert
  on PAPER
  for each row
begin
  select PAPER_SEQ.nextval into :new.PAPER_ID from dual;
end PAPER_ID_TRIGGER;
/

