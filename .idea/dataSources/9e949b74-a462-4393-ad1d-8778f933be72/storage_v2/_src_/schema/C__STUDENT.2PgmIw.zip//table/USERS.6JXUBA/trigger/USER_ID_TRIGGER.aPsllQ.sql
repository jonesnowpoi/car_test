create trigger USER_ID_TRIGGER
  before insert
  on USERS
  for each row
begin
  select USERS_SEQ.nextval into :new.USER_ID from dual;
end USER_ID_TRIGGER;
/

