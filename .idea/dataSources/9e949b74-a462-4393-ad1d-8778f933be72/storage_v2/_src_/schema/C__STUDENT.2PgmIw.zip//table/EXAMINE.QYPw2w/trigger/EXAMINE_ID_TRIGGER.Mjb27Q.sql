create trigger EXAMINE_ID_TRIGGER
  before insert
  on EXAMINE
  for each row
begin
  select EXAMINE_SEQ.nextval into :new.ID from dual;
end EXAMINE_ID_TRIGGER;
/

